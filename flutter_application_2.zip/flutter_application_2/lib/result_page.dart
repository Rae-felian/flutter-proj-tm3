import 'package:flutter/material.dart';

class ResultPage extends StatelessWidget {
  const ResultPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Terima data dari halaman form
    final Map<String, String> formData = 
        ModalRoute.of(context)!.settings.arguments as Map<String, String>;
    
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Hasil Pengiriman',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.close, color: Colors.black),
            onPressed: () {
              Navigator.popUntil(context, ModalRoute.withName('/'));
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              const Color(0xFFE3F2FD), // Light blue 50
              const Color(0xFFBBDEFB), // Light blue 100
              const Color(0xFF90CAF9), // Light blue 200
            ],
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Success icon dan text
                const Center(
                  child: CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.green,
                    child: Icon(
                      Icons.check,
                      color: Colors.white,
                      size: 50,
                    ),
                  ),
                ),
                
                const SizedBox(height: 24),
                
                const Center(
                  child: Text(
                    'Terima Kasih!',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ),
                
                const SizedBox(height: 8),
                
                const Center(
                  child: Text(
                    'Formulir Anda telah berhasil dikirim',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black54,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                
                const SizedBox(height: 40),
                
                // Kotak hasil
                Container(
                  padding: const EdgeInsets.all(24.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        spreadRadius: 1,
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Detail Pengiriman Formulir',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1976D2), // Blue color
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                      const Divider(),
                      const SizedBox(height: 20),
                      
                      // Nama
                      _buildResultRow(
                        icon: Icons.person,
                        label: 'Nama Lengkap',
                        value: formData['nama'] ?? '-',
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // NIM
                      _buildResultRow(
                        icon: Icons.badge,
                        label: 'NIM',
                        value: formData['nim'] ?? '-',
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Umur
                      _buildResultRow(
                        icon: Icons.cake,
                        label: 'Umur',
                        value: '${formData['umur'] ?? '-'} tahun',
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Email
                      _buildResultRow(
                        icon: Icons.email,
                        label: 'Email',
                        value: formData['email'] ?? '-',
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Telepon
                      _buildResultRow(
                        icon: Icons.phone,
                        label: 'Nomor Telepon',
                        value: formData['telepon'] ?? '-',
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Alamat
                      _buildResultRow(
                        icon: Icons.home,
                        label: 'Alamat',
                        value: formData['alamat'] ?? '-',
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Pesan
                      _buildResultRow(
                        icon: Icons.message,
                        label: 'Pesan',
                        value: formData['pesan'] ?? '-',
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 40),
                
                // Tombol kembali ke halaman utama
                Container(
                  height: 55,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        spreadRadius: 1,
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.popUntil(context, ModalRoute.withName('/'));
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1976D2), // Blue
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      elevation: 0,
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Kembali ke Beranda',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 8),
                        Icon(Icons.home),
                      ],
                    ),
                  ),
                ),
                
                const SizedBox(height: 40),
                
                // Footer
                Column(
                  children: [
                    const Text(
                      '© 2025 Raeldy',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    
                    const SizedBox(height: 15),
                    
                    // Social media icons
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Facebook icon
                        IconButton(
                          icon: const Icon(
                            Icons.facebook,
                            color: Colors.black,
                            size: 30,
                          ),
                          onPressed: () {
                            // Handle Facebook link
                          },
                        ),
                        
                        const SizedBox(width: 20),
                        
                        // TikTok icon
                        IconButton(
                          icon: const Icon(
                            Icons.music_note,
                            color: Colors.black,
                            size: 30,
                          ),
                          onPressed: () {
                            // Handle TikTok link
                          },
                        ),
                        
                        const SizedBox(width: 20),
                        
                        // YouTube icon
                        IconButton(
                          icon: const Icon(
                            Icons.play_circle_fill,
                            color: Colors.black,
                            size: 30,
                          ),
                          onPressed: () {
                            // Handle YouTube link
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  
  // Helper method
  Widget _buildResultRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CircleAvatar(
          radius: 20,
          backgroundColor: const Color(0xFFBBDEFB), // Light blue accent
          child: Icon(
            icon,
            color: const Color(0xFF1976D2), // Blue color
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 18,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}